import React from "react";
import './Styles.css'

const Header = () => {
  return (

    <div className="header">headers files</div>
  );
};

export default Header;
